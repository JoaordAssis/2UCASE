<?php

    header(location: '../view/adm.php');


?>
let navbar = document.getElementById("nav-header");
let containerMain = document.querySelector(".container-produto");


let heightNew = containerMain.clientHeight + 100;
navbar.style.height = heightNew + "px";
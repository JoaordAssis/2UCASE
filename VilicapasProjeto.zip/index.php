<?php
header("Location: ./app/view/homepage.php");
exit();
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <?php require_once __DIR__ . "/../config/stylesConfig.php"  ?>
    <link rel="stylesheet" href="../assets/styles/nav-simple.css">

</head>

<body>
    <header>
        <h1 id="logo-site"><a href="./homepage.php">2UCASE</a></h1>
    </header>
</body>

</html>
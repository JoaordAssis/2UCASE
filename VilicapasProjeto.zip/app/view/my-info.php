<?php
session_start();

if(empty($_SESSION['USER-ID'])){
    header("Location: ./homepage.php?error-code=OA00");
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <?php require_once __DIR__ . "/../config/stylesConfig.php"  ?>
    <link rel="stylesheet" href="../assets/styles/my-info.css">

</head>
<!-- Barra de Navegação -->
<?php require_once './navbar.php'; ?>

<body id="body-margin">
    <main class="container-new-produto">
        <h1>Minhas Informações</h1>
        <section class="edit-info-user">
            <form action="../controller/ControllerAddProdutoADM.php" method="POST" class="form-add-produto" enctype="multipart/form-data">

                <label for="nome_cliente">
                    <input type="text" required name="nome_cliente" id="input-nome" placeholder="Nome Completo">
                </label>

                <label for="email_cliente">
                    <input type="text" required name="email_cliente" id="input-nome" placeholder="Email">
                </label>

                <label for="cpf_cliente">
                    <input type="text" required name="cpf_cliente" id="input-nome" placeholder="CPF">
                </label>


                <div class="row-preco-quant row-inputs">
                    <label for="telefone_cliente">
                        <input type="text" required data-js="money" name="telefone_cliente" id="input-preco" placeholder="Número do Celular">
                    </label>

                    <label for="telefoneFixo_cliente">
                        <input type="number" required name="telefoneFixo_cliente" min="0" id="input-quant" placeholder="Telefone Fixo">
                    </label>
                </div>

                <div class="row-preco-quant row-inputs">
                    <label for="data_nasc_cliente">
                        <input type="date" required name="data_nasc_cliente" id="input-peso" placeholder="Data de Nascimento">
                    </label>

                    <select required name="genero_cliente" id="select-garantia">
                        <option selected>Genêro</option>
                        <option value="0">Masculino</option>
                        <option value="1">Femininos</option>
                        <option value="2">Não informar</option>
                    </select>
                </div>

                <input type="submit" value="Adicionar">
            </form>

        </section>

        <article class="container-enderecos">
            <h1>Meus Endereços</h1>

            <section class="flex-enderecos">
                <div class="box-endereco">
                    <p>Endereço 1</p>
                    <div class="row-log-numero row-endereco">
                        <p>Rua Balela Vieira</p>
                        <p>30</p>
                    </div>

                    <div class="row-bairro-cep row-endereco">
                        <p>Jardim Guarujá</p>
                        <p>05876-040</p>
                    </div>

                    <div class="row-cidade-uf row-endereco">
                        <p>São Paulo</p>
                        <p>SP</p>
                    </div>
                </div>

                <div class="box-endereco">
                    <p>Endereço 1</p>
                    <div class="row-log-numero row-endereco">
                        <p>Rua Balela Vieira</p>
                        <p>30</p>
                    </div>

                    <div class="row-bairro-cep row-endereco">
                        <p>Jardim Guarujá</p>
                        <p>05876-040</p>
                    </div>

                    <div class="row-cidade-uf row-endereco">
                        <p>São Paulo</p>
                        <p>SP</p>
                    </div>
                </div>

                <div class="box-endereco">
                    <p>Endereço 1</p>
                    <div class="row-log-numero row-endereco">
                        <p>Rua Balela Vieira</p>
                        <p>30</p>
                    </div>

                    <div class="row-bairro-cep row-endereco">
                        <p>Jardim Guarujá</p>
                        <p>05876-040</p>
                    </div>

                    <div class="row-cidade-uf row-endereco">
                        <p>São Paulo</p>
                        <p>SP</p>
                    </div>
                </div>
            </section>

            <button id="btn-add-endereco" onclick="window.location.href='./listProdutos.php'">Adicionar outro Endereco</button>

            <button id="btn-exit" onclick="window.location.href='./listProdutos.php'">Voltar</button>
        </article>
    </main>
</body>

</html>